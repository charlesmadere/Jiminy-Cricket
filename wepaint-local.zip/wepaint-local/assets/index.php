<?php


	// redirect the user to our 404 page because we
	// don't want people messing around in this dir
	header("location: http://www.wepaint.us/404.html");


	// Team Jiminy Cricket


?>